#include "headers.h"

/* CS1037a 2021 */
/* Assignment 04 */
/* Abeer Muhammad */
/* 251143649 */
/* Amuham23 */
/* November 4th, 2021 */
int main()
{
    int nArrs, row,column;
    int ***nTables;

    printf("\nEnter the number of arrays ( 0 to quit): ");
    scanf("%d", &nArrs);


    while (nArrs != 0){
        printf("\nEnter values for rows, columns (e.g.2 3): ");
        scanf("%d %d", &row, &column);
        nTables = (int ***) calloc (nArrs+1, sizeof(int **));
        initArrays(nTables,nArrs,row,column);
        //combineArrays();

        printArrays(nTables,nArrs,row,column);
       // arraySort(nTables[nArrs], row, column);
       // printArrays (nTables,nArrs, row, column, PRINTTOTALSORTED);
        printf("\nXXXXXXX END OF SESSION XXXXXX\n\n");
        printf("Enter the number of arrays (0 to quit): ");
        scanf ("%d", &nArrs);

    }

    return 0;

}
void initArrays (int ***tab, int arrs, int row, int column){
//    for (int i = 0; i < arrs; i++){
//        tab[i] = (int **)malloc(row * sizeof(int *));
//
//        if (tab[i] == NULL){
//            fprintf(stderr, "Out of Memory");
//            exit (0);
//        }
//        for (int j = 0; j < row; j++){
//            tab[i][j] = (int *)malloc(column * sizeof(int));
//            if (tab[i][j] == NULL){
//                fprintf(stderr, "Out of Memory");
//                exit (0);
//            }
//        }
//    }
    int upperb = arrs*row*column*10;
    int lowerb = 0;
    for (int i = 0; i<arrs ; i++){
        for (int j = 0 ; j<row ; j++){
            for (int k = 0; k < column ; k++){
                tab[i][j][k] = rand() % (upperb - lowerb +1)+lowerb;
            }
        }
    }
     for (int i = arrs; i<arrs+1; i++){
        for (int j = 0 ; j<row ; j++){
            for (int k = 0; k < column ; k++){
                tab[i][j][k] = 0;
            }
        }
    }

}
void printArrays (int ***tab2, int arrs2, int row2, int column2){
    printf("love");
    for (int i = 0; i<arrs2 ; i++){
        for (int j = 0 ; j<row2; j++){
            for (int k = 0; k < column2 ; k++){
                printf ( "%d ", tab2[i][j][k]);
            }

        }
      printf ( "\n");
    }

}
