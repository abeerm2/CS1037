/* CS1037a 2021 */
/* Assignment 01 */
/* Abeer Muhammad */
/* 251143649 */
/* AMUHAM23 */
/* September 23, 2021 */

#include <stdio.h>
#include <stdlib.h>

int main()
{
    long long  x1 = -1; // previous term - // the difference between int and long in the program is not present they will both end at the 46th term of the fibonacci sequence before it turns into negative and can no longer take more space
    long long x2 = 1; //current term - // the long long variable type allows for larger number before it reaches negatives, meaning that it can achieve the 92nd fibonacci sequence.
    long long sum = x1+x2; // sum the previous and current originally
    int count = 0; // counts what term of the fibonacci sequence
    int count2 = 0; // this is for building a title line

    printf("Fibonacci Sequence: Until Overflow:\n");//title
    do { //uses loop to produce 34 dashes underneath the title
        printf("-");
        count2++;

    }while (count2<35);
    printf("\n");

    do
        {
        printf("%d: %lld\n",count,sum ); // prints out the term number and then the sum of the two numbers
        x1 = x2; //assigns the current value to the previous value
        x2 = sum; // assigns the sum to be the current value
        sum = x1+x2; //new sum
        count++; // increases term count

    }while(sum>=0); // while sum remains positive


    /* QUESTION 2 - identifying all the prime numbers in a given interval */

    // declaring variables
    int high; //upper bound
    int low; //lower bound
    int i;
    int j;
    int divCount = 0; // counts how many times it can be divided by the range of numbers when mod = 0
    // declaring variables

    printf("\n\nEnter two range (input integer numbers only):"); // asks user to input range
    scanf ("%i %i",&low,&high); // assigns values to high and low variables from user input
    printf("Prime numbers from %i and %i are:\n", low, high );
    if (low == 1){
        low++;
    }

    while (low<=high){
        j = low; // assigns low to var j
        low++;// adds to low because its between two numbers not including

        for (i=1; i<high;i++){ // for loop which runs through all the numbers between 1 and the upperbound and divides the number at the given time to see if has mod 0
            if (j%i == 0){ // if low mod number is zero then adds to the count variable
                divCount++;
            }
        }
         if (divCount>2){ //if count is greater than 2 then it is not a prime number because that means it's divisible by more than 1 and itself
                divCount = 0; // count reset
            }
            else{
                printf("%i\n",j); //if count isn't greater than 2 then that number is printed in output and count reset to zero
                divCount = 0;
            }
    }

    // QUESTION 3 - Grade conversion from numeric to letter grading question

    double grade; // declares variable called grade

    printf("\n\nGrade Conversion from numeric to letter grading: ");// asks user for the number grade
    scanf("%lf",&grade); // assigns numeric value to grade

    // uses if statements to compare the grades and then outputs statement based on numeric value
    if (grade > 0 && grade <51){ // if grade >0 and less than 51 then prints fail
        printf("FAIL");
    }
     else if (grade<0 || grade>100 ) // if negative or above 100 then it is out of bounds
        printf("Out of Bounds");

    else if (grade<61) // if grade from 51 but less than 61 prints a D
        printf("D");

    else if (grade<71) // if grade from 61 but less than 71  prints C
        printf("C");

    else if (grade<81) // if grade from 71 but less than 81 then B
        printf("B");

    else if (grade<91) // if grade from 81 but less than 91 then prints A
        printf("A");

    else // anything else is an A+
        printf("A+");

    /* answer to if this is possible to convert to switch statements: Yes it is possible one way to do it would be taking the inputed grade and then dividing it by a factor of 10
    then using that you could create switch cases that relate to each individual number for example Case 8 would refer to numbers within the 80s and it would output an A/B
    however you's likely need an additional if statement before it runs through the switch statement which would check if it was in bounds or not */


    // QUESTION 4 -  USES switch and case statements to determine what delivery type a class is by an associated number

    int number;
    printf("\n\nClass Section Conversion from numeric to text description : based on a value of: ");

    scanf ("%li",&number); // gets user input
    switch(number){
    case 1: //user enters 1
        printf("Day Class");
        break;
    case 2: //user enters 2
        printf("Night Class");
        break;
    case 650: // user enters 3
        printf("Online Class");
        break;

    default:
        printf("Illegal Section");
        break;
    }

    return 0;
}
