#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* CS1037a 2021 */
/* Assignment 02 */
/* Abeer Muhammad*/
/* 251143649 */
/* Amuham23 */
/* October 6, 2021 */

int main()

{
    srand(time(NULL));
    int num =3;// number of iterations
    long lowerb = 50; // lower bound of the range in the amount of elements in array
    long upperb = num*50; // upper bound of the possible amount of elements which can be generated
    long lowerb2 = 1; //lower bound for the actual numbers which can be generated in the array
    long upperb2 = 1; // upperbound declaration
    int debugging = 0; // only if debugging is set to 1 will it run the debugging statements
    int number1;
    int number2;
    int higher;
    int arrayL = rand() % (upperb - lowerb+1)+lowerb; // determining length of the array ( being between 50 and 50 times the number of iterations
    int afinal[arrayL]; // declaring and initializing the array
    int numarr = arrayL;



    // determines the upper range value of what numbers could possibly be based on iterations
    for (int o = 1;o<=num;o++){
        upperb2*= 10;
    }

    ///DEBUGGING IF DEBUG VARIABLE SET TO 1 ///
    if (debugging == 1){
        printf ("\nUpperb2 = %d\n\n",upperb2);
    }
    /// DISPLAYS size of the array (random) and the bytes calculation
    printf ("\nValue of random size of array: %d\n", arrayL);
    printf("Size of array (bytes): %d\n\n", arrayL*4);

    /// FOR LOOP RUNNING THROUGH EACH ITERATION
    for (int k = 1; k<=num;k++){
        arrayL = numarr;
         printf("\n----------------------------------------------------------------\n\nTHIS IS ITERATION #%d of #%d\n", k,num); // TITLE
         printf ("This is the original array populated with values in the range of %d and %d\n", lowerb2,upperb2); // shows the range the numbers should be in for that that iteration
         printf("Number of elements in the original array is: %d\n\n\t", arrayL); // displays number of elements

         /// RANDOMIZES THE NUMBERS IN ARRAYS
        for (int i = 0; i<arrayL;i++){
            afinal[i] =rand() % upperb2 + 1;
        }
        /// OUTPUTS THE ORIGINAL ARRAY WITH FORMATTING
        for (int j = 0; j < arrayL;j++){
            printf("%d\t",afinal[j]);
        }
        /// LOOKS FOR DUPLICATES WITHIN THE ARRAY
        for (int z = 0; z<arrayL;z++){ // will take the first element and compare to every other element (through using nested for) in the array and then will do the next number and compare
            for (int h = z+1;h<arrayL;h++){
                    number1 = afinal[z];
                    number2 = afinal[h];
                if (number1 == number2){ /// IF THE two numbers are equal then will run this section


                        if (debugging == 1){ // will only run if debugging var is set to 1
                            printf("\nThe value of %d at array index [%d] and the value %d at array index[%d] are the same.", number1,z,number2,h);

                        }
                        for (int t = h;t<arrayL-1;t++){ /// THIS SECTION MAKES THE DUPLICATE DISAPEAR
                            afinal[t] = afinal[t+1];
                        }
                    arrayL--; // REDUCES THE ARRAY (lowers its size)
                    h--; // GOES BACK In h so it can compare if there is a duplicate without missing numbers because of it shifts back
            }
        }
    }
    /// THIS PART OUTPUTS THE ARRAY WITH ALL THE DUPLICATES REMOVED
    printf("\nThis is the current state of the array with all duplicate values removed\n");
    printf("Number of unique (non-zero, non-duplicate) elements in the array is: %d\n\t",arrayL);
     for (int j = 0; j < arrayL;j++){ /// loop displays the array - same as above
            printf("%d\t",afinal[j]);
        }

    /// THIS PART ORGANIZES THE ARRAY AND OUTPUTS IN ASCENDING ORDER
    printf("\nThese are the unique, non-zero elements in the array sorted in ascending order:\n\t");
    for (int a = 0; a < arrayL;a++){ // TAKES FIRST NUMBER
        for(int g = a+1; g<arrayL;g++){ // COMPARES TO EVERY OTHER NUMBER, ONCE COMPLETE WILL TAKE THE NEXT VALUE of a AND DO THE SAME
            if (afinal[a]>afinal[g]){ // IF NUMBER IS GREATER THAN THE NEXT ONE
                higher = afinal[a]; // IT MAKES HIGHER EQUAL TO THAT
                afinal[a] = afinal[g]; // THEN THAT A POSITION IS NOW THE NUMBER IN THE G POSITION
                afinal[g] = higher; // G IS NOW THE a NUMBER
                }
            }
        }
        /// PRINTS OUT THE ARRAY WITH ALL NUMBERS ORGANIZED IN ASCENDING NUMBERS - same as above
        for (int x = 0; x < arrayL;x++){
            printf("%d\t",afinal[x]);
        }
    upperb2/=10; // DIVIDES UPPER RANGE BY 10 TO MOVE TO NEXT ITERATION
    }
     return 0;
}
